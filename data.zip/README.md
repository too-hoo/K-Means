# K-Means(K-均值)算法：如何给20支亚洲球队做聚类

## K-Means的工作原理

## 如何给亚洲球队做聚类

## 如何使用sklearn中的K-Means算法

## 总结